# replit.md

## Overview

This is a full-stack educational portal web application built with a modern tech stack including React (TypeScript), Express.js, PostgreSQL, and Drizzle ORM. The application supports both React-based frontend and traditional HTML/CSS/JavaScript frontend components, indicating a hybrid approach to web development.

## System Architecture

### Frontend Architecture
- **Primary Frontend**: React with TypeScript using Vite as the build tool
- **Secondary Frontend**: Traditional HTML/CSS/JavaScript files in the `public/` directory
- **UI Framework**: Tailwind CSS with shadcn/ui component library
- **Styling**: Custom CSS variables and utility classes with dark mode support
- **State Management**: React Query for server state management

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **Session Management**: Express sessions with connect-pg-simple for PostgreSQL session store
- **Authentication**: bcrypt for password hashing
- **API Design**: RESTful API with `/api` prefix

### Database Architecture
- **Database**: PostgreSQL (configured via DATABASE_URL)
- **ORM**: Drizzle ORM with migrations support
- **Connection**: Neon Database serverless connection
- **Schema**: Centralized schema definitions in `shared/schema.ts`

## Key Components

### Authentication System
- **User Management**: Username/password authentication with bcrypt hashing
- **Session Storage**: PostgreSQL-backed sessions
- **Role-based Access**: Support for student and teacher roles
- **Middleware**: Authentication middleware for protected routes

### Frontend Components
- **React Components**: Comprehensive shadcn/ui component library
- **Form Handling**: React Hook Form with Zod validation
- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Accessibility**: ARIA compliant components from Radix UI

### Backend Services
- **Storage Interface**: Abstracted storage layer with in-memory fallback
- **Error Handling**: Centralized error handling middleware
- **Development Tools**: Vite integration for development mode
- **Logging**: Request logging with performance metrics

## Data Flow

1. **Client Requests**: React frontend makes API calls to Express backend
2. **Authentication**: Session-based authentication with middleware validation
3. **Data Processing**: Backend processes requests and interacts with PostgreSQL
4. **Response**: JSON responses sent back to frontend
5. **State Management**: React Query manages client-side state and caching

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless connection
- **drizzle-orm**: Database ORM with TypeScript support
- **@tanstack/react-query**: Server state management
- **@radix-ui**: Accessible UI primitives
- **bcrypt**: Password hashing
- **express-session**: Session management

### Development Dependencies
- **Vite**: Build tool and development server
- **TypeScript**: Type safety across the stack
- **Tailwind CSS**: Utility-first CSS framework
- **ESBuild**: Fast JavaScript bundler for production

## Deployment Strategy

### Build Process
- **Development**: `npm run dev` - runs TypeScript server with hot reload
- **Production Build**: `npm run build` - builds both frontend and backend
- **Frontend**: Vite builds React app to `dist/public`
- **Backend**: ESBuild bundles server code to `dist/index.js`

### Database Management
- **Migrations**: Drizzle migrations stored in `./migrations`
- **Schema Push**: `npm run db:push` for schema synchronization
- **Environment**: DATABASE_URL required for all database operations

### Production Deployment
- **Start Command**: `npm start` runs the bundled application
- **Static Files**: Frontend assets served from `dist/public`
- **Environment**: NODE_ENV=production for optimized performance

## Changelog

```
Changelog:
- June 30, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```